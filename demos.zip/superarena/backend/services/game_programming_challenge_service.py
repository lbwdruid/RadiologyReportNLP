import re, json, tempfile
from subprocess import run
from backend.config import get_label_map
from backend.core.llm import ask

# === 工具函数 ===
def extract_block(label, text, next_labels):
    pattern = rf"{label}[:：]?\s*(.+?)(?=\n(?:{'|'.join(next_labels)})[:：])"
    match = re.search(pattern, text, re.S)
    return match.group(1).strip() if match else ""

def extract_code_block(label, text):
    pattern = rf"{label}[:：]?\s*```(?:python)?\s*(.+?)```"
    match = re.search(pattern, text, re.S)
    return match.group(1).strip() if match else ""

def extract_json_block(text):
    match = re.search(r"```json\s*(\[\{.+?\}\])\s*```", text, re.S)
    return json.loads(match.group(1)) if match else []

# === 出题接口 ===
def generate_challenge(model: str, topic: str, lang: str = "en"):
    from backend.config import get_prompt
    prompt = get_prompt("game_programming_challenge", lang).replace("{topic}", topic)

    text = ask(prompt, model=model)
    labels = get_label_map("game_programming_challenge", lang)

    try:
        parsed = {
            "raw": text,
            "description": extract_block(labels["desc"], text, [labels["input"], labels["output"], labels["example"], labels["solution"]]),
            "input": extract_block(labels["input"], text, [labels["output"], labels["example"], labels["solution"]]),
            "output": extract_block(labels["output"], text, [labels["example"], labels["solution"]]),
            "example": extract_block(labels["example"], text, [labels["solution"]]),
            "answer": extract_code_block(labels["solution"], text),
            "testcases": extract_json_block(text)
        }
    except Exception as e:
        return {
            "status": "parse_error",
            "error": str(e),
            "raw": text
        }

    # 评估 AI 提供的答案是否通过测试
    try:
        local_vars = {}
        exec(parsed["answer"], {}, local_vars)
        solution = local_vars.get("solution")
        for case in parsed["testcases"]:
            if str(solution(case["input"])) != str(case["output"]):
                raise ValueError("Test case failed")
    except Exception as e:
        return {
            "status": "fail_tests",
            "error": str(e),
            "raw": text
        }

    return { "status": "success", "question": parsed }

# === 用户/AI 提交代码 ===
def submit_code(user_code: str, testcases_json: str):
    try:
        testcases = json.loads(testcases_json)
        all_passed = True
        failed_cases = []

        for case in testcases:
            input_val = case["input"]
            expected = str(case["output"])

            test_code = f"""
{user_code}

if __name__ == "__main__":
    result = solution({repr(input_val)})
    print(result)
"""

            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
                tmp.write(test_code)
                tmp_filename = tmp.name

            completed = run(["python", tmp_filename], capture_output=True, text=True, timeout=5)
            output = completed.stdout.strip()
            error = completed.stderr.strip()

            if output != expected or error:
                all_passed = False
                failed_cases.append({
                    "input": input_val,
                    "expected": expected,
                    "got": output,
                    "error": error if error else None
                })

        return {
            "status": "success" if all_passed else "fail",
            "details": failed_cases
        }

    except Exception as e:
        return {"status": "error", "error": str(e)}

# === AI 自动解答 ===
def ai_solve_code(description, input, output, testcases_json, model, lang="en"):
    prompt = (
        f"You are asked to solve a Python programming problem.\n"
        f"Description: {description}\nInput: {input}\nOutput: {output}\n"
        "Please write only the Python function `solution(...)` that solves this.\n"
        "Respond using:\n```python\n<your code>\n```"
    )

    response = ask(prompt, model=model)
    try:
        code = re.search(r"```python\s*(.+?)```", response, re.S).group(1).strip()
    except:
        code = response.strip()

    result = submit_code(code, testcases_json)
    return {
        "code": code,
        "submit_result": result
    }

import os
import json
import time
from filelock import FileLock

HISTORY_FILE = "data/history_game_programming_challenge.json"
LOCK_FILE = HISTORY_FILE + ".lock"

def save_match_history(entry: dict):
    lock = FileLock(LOCK_FILE, timeout=10)  # 最多等10秒获取锁
    try:
        with lock:  # 🔐 自动加锁，退出自动释放
            if not os.path.exists(HISTORY_FILE):
                with open(HISTORY_FILE, "w", encoding="utf-8") as f:
                    json.dump([], f)

            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                history = json.load(f)

            history.append(entry)

            with open(HISTORY_FILE, "w", encoding="utf-8") as f:
                json.dump(history, f, ensure_ascii=False, indent=2)

    except Exception as e:
        print("❌ Failed to save match history:", e)

LEADERBOARD_FILE = "data/leaderboard_game_programming_challenge.json"
LEADERBOARD_LOCK = LEADERBOARD_FILE + ".lock"

from filelock import FileLock

def update_leaderboard(name, type_, won):
    lock = FileLock(LEADERBOARD_LOCK)
    try:
        with lock:
            # 初始化文件
            if not os.path.exists(LEADERBOARD_FILE):
                with open(LEADERBOARD_FILE, "w") as f:
                    json.dump([], f)

            with open(LEADERBOARD_FILE, "r", encoding="utf-8") as f:
                board = json.load(f)

            # 找现有 entry
            entry = next((x for x in board if x["name"] == name), None)
            if not entry:
                entry = {
                    "name": name,
                    "type": type_,
                    "score": 0,
                    "games": 0,
                    "win_rate": 0.0
                }
                board.append(entry)

            # 更新数据
            entry["games"] += 1
            if won:
                entry["score"] += 1
            entry["win_rate"] = round(entry["score"] / entry["games"], 3)

            # 写回文件
            with open(LEADERBOARD_FILE, "w", encoding="utf-8") as f:
                json.dump(board, f, indent=2, ensure_ascii=False)

    except Exception as e:
        print("❌ Failed to update leaderboard:", e)

import os, json
from backend.services.game_programming_challenge_service import generate_challenge, ai_solve_code, submit_code
from backend.core.prompt_map import get_prompt

def run_match_round(match_id: str):
    match_file = f"data/matches/game_programming_challenge_{match_id}.json"
    if not os.path.exists(match_file):
        raise Exception("Match not found")

    with open(match_file, "r", encoding="utf-8") as f:
        match = json.load(f)

    players = match["players"]
    round_idx = match["current_round"]
    current_turn = players[round_idx % len(players)]
    scoreboard = match["scoreboard"]

    # 1. 出题
    is_human = current_turn == match.get("human")
    if is_human:
        raise Exception("Human round not supported yet")  # 先只支持 AI 出题

    prompt = get_prompt("game_programming_challenge", lang="en")
    challenge = generate_challenge(
        model=current_turn,
        topic="Python easy",
        lang="en",
        custom_prompt=prompt
    )

    if challenge.get("status") != "success":
        raise Exception("Challenge generation failed")

    question = challenge["question"]
    testcases = question["testcases"]
    standard_code = question["answer"]

    # 2. 标准答案验证（先测出题人自己的答案）
    std_result = submit_code(standard_code, json.dumps(testcases))
    if std_result.get("status") != "success":
        # 题错了 → 出题者扣1分，其他人各得1分
        for p in players:
            if p != current_turn:
                scoreboard[p] += 1
        round_summary = {
            "round": round_idx + 1,
            "turn": current_turn,
            "error": "AI's own solution failed",
            "score_change": {p: (1 if p != current_turn else -1) for p in players}
        }
        scoreboard[current_turn] -= 1
    else:
        # 3. 所有其他人答题
        round_score = {}
        all_passed = 0
        for p in players:
            if p == current_turn:
                continue
            solve_result = ai_solve_code(
                description=question["description"],
                input=question["input"],
                output=question["output"],
                testcases_json=json.dumps(testcases),
                model=p,
                lang="en"
            )
            passed = solve_result.get("submit_result", {}).get("status") == "success"
            round_score[p] = 1 if passed else 0
            if not passed:
                scoreboard[current_turn] += 1  # 出题人得分：有 AI 答错

        round_summary = {
            "round": round_idx + 1,
            "turn": current_turn,
            "score_change": round_score,
            "question": question
        }

        for p, score in round_score.items():
            scoreboard[p] += score

    # 4. 更新状态
    match["rounds"].append(round_summary)
    match["scoreboard"] = scoreboard
    match["current_round"] += 1
    match["status"] = "running"

    with open(match_file, "w", encoding="utf-8") as f:
        json.dump(match, f, indent=2)

    return round_summary
