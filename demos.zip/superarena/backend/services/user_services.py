import os
import json
import hashlib
from passlib.context import CryptContext

USER_FILE = "data/users.json"

# 使用 Passlib 提供的加密算法
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def load_users():
    if not os.path.exists(USER_FILE):
        with open(USER_FILE, "w") as f:
            json.dump([], f)

    with open(USER_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_users(users):
    with open(USER_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=2, ensure_ascii=False)


def register_user(username, password):
    users = load_users()
    if any(u["username"] == username for u in users):
        return False, "Username already exists"

    hashed = pwd_context.hash(password)
    users.append({
        "username": username,
        "password": hashed
    })
    save_users(users)
    return True, "Registered successfully"


def verify_user(username, password):
    users = load_users()
    user = next((u for u in users if u["username"] == username), None)
    if not user:
        return False, "User not found"
    if not pwd_context.verify(password, user["password"]):
        return False, "Incorrect password"
    return True, "Login success"


def get_user(username):
    users = load_users()
    return next((u for u in users if u["username"] == username), None)
