import os
from dotenv import load_dotenv
import json

load_dotenv()

class Settings:
    OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

settings = Settings()

def get_model_list():
    with open("data/models.json", "r", encoding="utf-8") as f:
        return json.load(f)

def get_prompt(game, lang="en"):
    with open("data/prompts.json", "r", encoding="utf-8") as f:
        all_prompts = json.load(f)
    return all_prompts.get(game, {}).get(lang)

def get_label_map(game, lang="en"):
    with open(f"data/prompt_labels/{game}.json", "r", encoding="utf-8") as f:
        all_labels = json.load(f)
    return all_labels.get(lang, all_labels["en"])
