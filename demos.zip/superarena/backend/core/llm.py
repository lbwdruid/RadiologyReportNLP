import os
from dotenv import load_dotenv
from openai import OpenAI
from backend.core.prompt_map import get_prompt

load_dotenv()

client = OpenAI(
    api_key=os.getenv("OPENROUTER_API_KEY"),
    base_url="https://openrouter.ai/api/v1"
)

def ask(prompt: str, model: str = "openai/gpt-3.5-turbo", temperature: float = 0.7):
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"[ERROR calling LLM: {str(e)}]"


def ask_for_game(game: str, lang: str, model: str, context: dict):
    """
    根据游戏类型、语言、上下文自动生成 prompt 并调用 LLM。
    """
    prompt = get_prompt(game, lang)
    return ask(prompt=prompt, model=model)
