import json
import os

PROMPT_FILE = "data/prompts.json"
LABEL_FILE_DIR = "data/prompt_labels/"


def get_prompt(game: str, lang: str = "en") -> str:
    if not os.path.exists(PROMPT_FILE):
        raise FileNotFoundError(f"{PROMPT_FILE} not found.")

    with open(PROMPT_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)

    game_prompts = data.get(game)
    if not game_prompts:
        raise ValueError(f"No prompt defined for game '{game}'")

    return game_prompts.get(lang) or game_prompts.get("en") or next(iter(game_prompts.values()))


def get_labels(game: str, lang: str = "en") -> dict:
    label_file = os.path.join(LABEL_FILE_DIR, f"{game}.json")
    if not os.path.exists(label_file):
        raise FileNotFoundError(f"{label_file} not found.")

    with open(label_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    return data.get(lang) or data.get("en") or next(iter(data.values()))
