import json
import os
import uuid
from fastapi import APIRouter, Form, Request
from backend.services.game_programming_challenge_service import generate_challenge, submit_code, ai_solve_code, run_match_round
from backend.services.game_programming_challenge_service import update_leaderboard  # 导入排行榜更新功能

router = APIRouter()

# 生成编程挑战
@router.post("/challenge")
def challenge(
    model: str = Form(...),
    topic: str = Form("Python easy"),
    lang: str = Form("en")
):
    return generate_challenge(model=model, topic=topic, lang=lang)

# 提交代码并评测
@router.post("/submit")
def submit(
    user_code: str = Form(...),
    testcases_json: str = Form(...)
):
    return submit_code(user_code=user_code, testcases_json=testcases_json)

# AI自动解答
@router.post("/ai/solve")
def ai_solve(
    description: str = Form(...),
    input: str = Form(...),
    output: str = Form(...),
    testcases_json: str = Form(...),
    model: str = Form(...),
    lang: str = Form("en")
):
    return ai_solve_code(description, input, output, testcases_json, model, lang)

# 获取排行榜
@router.get("/leaderboard")
def get_leaderboard():
    try:
        with open("data/leaderboard_game_programming_challenge.json", "r", encoding="utf-8") as f:
            board = json.load(f)
        return {"status": "success", "data": board}
    except Exception as e:
        return {"status": "error", "error": str(e)}

# 获取历史记录
@router.get("/history")
def get_match_history():
    try:
        with open("data/history_game_programming_challenge.json", "r", encoding="utf-8") as f:
            data = json.load(f)
        return {"status": "success", "data": data}
    except Exception as e:
        return {"status": "error", "error": str(e)}

# 更新排行榜
@router.post("/update_leaderboard")
def update_leaderboard_api(
    name: str = Form(...),
    type: str = Form(...),
    won: str = Form(...),
):
    try:
        update_leaderboard(name, type, won.lower() == "true")
        return {"status": "ok"}
    except Exception as e:
        return {"status": "error", "error": str(e)}

# 启动比赛
@router.post("/start-match")
def start_programming_match(
    include_human: bool = Form(...),
    selected_models: str = Form(...),
    request: Request = None
):
    try:
        selected_models = json.loads(selected_models)
        if not isinstance(selected_models, list):
            raise ValueError("selected_models must be a list")

        players = selected_models.copy()
        username = request.session.get("user", "anonymous")

        if include_human:
            players.append(username)

        if not (2 <= len(players) <= 8):
            return {"status": "fail", "error": "Total participants must be between 2 and 8"}

        # 默认人类出题排在最后
        ordered_players = [p for p in players if p != username] + ([username] if include_human else [])

        match_id = str(uuid.uuid4())[:8]
        match_data = {
            "match_id": match_id,
            "players": ordered_players,
            "rounds": [],
            "scoreboard": {p: 0 for p in ordered_players},
            "current_round": 0,
            "status": "waiting",  # 可扩展为 running / finished
            "human": username if include_human else None
        }

        # 保存比赛数据
        match_file = f"data/matches/game_programming_challenge_{match_id}.json"
        os.makedirs("data/matches", exist_ok=True)
        with open(match_file, "w", encoding="utf-8") as f:
            json.dump(match_data, f, indent=2)

        return {
            "status": "success",
            "match_id": match_id,
            "players": ordered_players
        }

    except Exception as e:
        return {"status": "fail", "error": str(e)}

# 获取比赛信息
@router.get("/match-info")
def get_match_info(match_id: str):
    match_file = f"data/matches/game_programming_challenge_{match_id}.json"
    
    if not os.path.exists(match_file):
        return {"status": "fail", "error": f"Match {match_id} not found."}
    
    try:
        with open(match_file, "r", encoding="utf-8") as f:
            match = json.load(f)

        return {
            "status": "success",
            "match": match
        }
    except Exception as e:
        return {"status": "fail", "error": str(e)}

# 进入下一回合
@router.post("/play-round")
def play_round(match_id: str = Form(...)):
    from backend.services.game_programming_challenge_service import run_match_round
    try:
        result = run_match_round(match_id)
        return {"status": "success", "round_summary": result}
    except Exception as e:
        return {"status": "fail", "error": str(e)}
