from fastapi import APIRouter, Form, Request, Response
from backend.services.user_services import (
    register_user, verify_user, get_user
)


router = APIRouter()


@router.post("/register")
def register(username: str = Form(...), password: str = Form(...)):
    success, msg = register_user(username, password)
    return {"status": "success" if success else "fail", "message": msg}


@router.post("/login")
def login(response: Response, username: str = Form(...), password: str = Form(...)):
    success, msg = verify_user(username, password)
    if success:
        response.set_cookie(key="user", value=username, httponly=True)
        return {"status": "success", "message": "Logged in"}
    return {"status": "fail", "message": msg}


@router.get("/logout")
def logout(response: Response):
    response.delete_cookie("user")
    return {"status": "success", "message": "Logged out"}


@router.get("/me")
def get_me(request: Request):
    user = request.cookies.get("user")
    if user:
        return {"status": "success", "user": user}
    return {"status": "unauthenticated"}
