from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.api import game_programming_challenge
from backend.api import user
from starlette.middleware.sessions import SessionMiddleware  # Correct import from starlette

app = FastAPI(title="SuperArena - LLM vs Human Playground")

# Allow cross-origin requests (useful for local testing)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add session middleware (ensure secret_key is set)
app.add_middleware(
    SessionMiddleware,
    secret_key="your-secret-key",  # Use a secure secret key
)

# Register game module
app.include_router(game_programming_challenge.router, prefix="/game/programming", tags=["Programming Challenge"])

# Register user module
app.include_router(user.router, prefix="/user")

@app.get("/")
def root():
    return {"message": "Welcome to SuperArena!"}
