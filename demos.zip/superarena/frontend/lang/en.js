export const en = {
  "title": "AI Programming Challenge",
  "submit": "Submit",
  "loading": "Loading challenge...",
  "result": "Evaluation Result",
  "you_win": "AI failed its own question. You win! 🎉"
};
