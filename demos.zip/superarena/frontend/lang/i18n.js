import { en } from './en.js';

const lang = en;

export function t(key) {
  return lang[key] || key;
}
