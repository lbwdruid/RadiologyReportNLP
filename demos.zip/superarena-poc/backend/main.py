from fastapi import FastAPI
from backend.auth import auth_router
from backend.llm import llm_router
from backend.game import game_router
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 或 ["null"] 也可以
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router, prefix="/auth")
app.include_router(llm_router, prefix="/llm")
app.include_router(game_router, prefix="/game")

@app.get("/")
def home():
    return {"msg": "AI Arena 后端已启动！"}

from backend.game import game_router
app.include_router(game_router, prefix="/game")
