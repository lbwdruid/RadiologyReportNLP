from fastapi import APIRouter, Form
from pydantic import BaseModel

auth_router = APIRouter()

fake_users = {}  # 简单模拟数据库

class User(BaseModel):
    username: str
    password: str

@auth_router.post("/register")
def register(username: str = Form(...), password: str = Form(...)):
    if username in fake_users:
        return {"status": "fail", "msg": "用户已存在"}
    fake_users[username] = password
    return {"status": "success", "msg": "注册成功"}

@auth_router.post("/login")
def login(username: str = Form(...), password: str = Form(...)):
    if fake_users.get(username) == password:
        return {"status": "success", "msg": "登录成功"}
    return {"status": "fail", "msg": "用户名或密码错误"}
