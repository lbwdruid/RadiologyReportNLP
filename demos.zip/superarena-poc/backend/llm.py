# llm.py
import os
from dotenv import load_dotenv
from openai import OpenAI
from fastapi import APIRouter, Form

load_dotenv()

client = OpenAI(
    api_key=os.getenv("OPENROUTER_API_KEY"),
    base_url="https://openrouter.ai/api/v1"
)

llm_router = APIRouter()

def ask(prompt: str, model: str = "mistralai/mistral-7b-instruct:free") -> str:
    """
    封装 LLM 调用。支持传入 prompt 和模型名。
    """
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"[LLM 调用失败] {e}"

# 用于 /llm/ask 接口测试
@llm_router.post("/ask")
def ask_api(prompt: str = Form(...), model: str = Form("mistralai/mistral-7b-instruct:free")):
    result = ask(prompt, model)
    if result.startswith("[LLM 调用失败]"):
        return {"status": "fail", "error": result}
    return {"status": "success", "answer": result, "model_used": model}
