from fastapi import APIRouter, Form
import re, json
from backend.llm import ask  # ✅ 使用封装好的 LLM 接口

game_router = APIRouter()

def extract_block(label, text, next_labels):
    pattern = rf"{label}[:：]?\s*(.+?)(?=\n(?:{'|'.join(next_labels)})[:：])"
    match = re.search(pattern, text, re.S)
    return match.group(1).strip() if match else ""

def extract_code_block(label, text):
    pattern = rf"{label}[:：]?\s*```(?:python)?\s*(.+?)```"
    match = re.search(pattern, text, re.S)
    return match.group(1).strip() if match else ""

def extract_json_block(text):
    match = re.search(r"```json\s*(\[\{.+?\}\])\s*```", text, re.S)
    return json.loads(match.group(1)) if match else []

@game_router.post("/ai-challenge")
def ai_generate_challenge(
    topic: str = Form("Python easy"),
    model: str = Form("mistralai/mistral-7b-instruct:free")
):
    """
    调用 AI 出一道人类要解答的编程题，并验证其标准答案是否正确。
    如果 AI 出的题存在问题（无法通过自身测试），返回 invalid_question。
    """
    prompt = (
        f"请你出一道{topic}难度的 Python 编程题，要求：\n"
        "- 包含题目描述、输入输出说明、一个示例输入输出。\n"
        "- **不要把所有测试用例暴露在题面中。**\n"
        "- 然后生成 5 个隐藏的测试用例，格式为 JSON 数组：[{\"input\": ..., \"output\": ...}]\n"
        "- 并附带一个标准答案函数（命名为 solution）。\n\n"
        "注意：题目由系统评测，你必须在题目中明确要求用户编写一个函数 solution(...)。该函数接受题目所说的输入作为参数，返回对应输出。\n"
        "请按以下格式返回（包括 JSON 块和代码块）：\n"
        "题目描述：...\n输入：...\n输出：...\n示例：...\n标准答案：```python\n...```\n测试用例：```json\n[{\"input\": ..., \"output\": ...}, ...]```"
    )


    text = ask(prompt, model=model)
    print("\n=== AI 回复原文 ===\n", text, "\n=======================")

    # 解析阶段
    try:
        parsed = {
            "raw": text,
            "description": extract_block("题目描述", text, ["输入", "输出", "示例", "标准答案"]),
            "input": extract_block("输入", text, ["输出", "示例", "标准答案"]),
            "output": extract_block("输出", text, ["示例", "标准答案"]),
            "example": extract_block("示例", text, ["标准答案"]),
            "answer": extract_code_block("标准答案", text),
            "testcases": extract_json_block(text)
        }
    except Exception as parse_err:
        return {
            "status": "parse_error",
            "error": "AI 回复格式不符合要求，无法提取题干/答案/测试用例。",
            "details": str(parse_err),
            "raw": text
        }

    # 执行标准答案并验证测试用例
    try:
        local_vars = {}
        exec(parsed["answer"], {}, local_vars)
        solution = local_vars.get("solution")
        if not callable(solution):
            raise ValueError("未定义 solution 函数")

        for case in parsed["testcases"]:
            input_val = case["input"]
            expected = str(case["output"])
            result = str(solution(input_val))
            if result != expected:
                raise ValueError(f"测试未通过：输入={input_val}，期望={expected}，实际={result}")

    except Exception as test_fail:
        return {
            "status": "fail_tests",
            "error": "标准答案无法通过测试用例，AI 出题失败。",
            "details": str(test_fail),
            "raw": text
        }

    return {"status": "success", "question": parsed}

# -------------------- 提交代码评测接口 --------------------

import subprocess
import tempfile

@game_router.post("/submit")
def submit_code(
    user_code: str = Form(...),
    testcases_json: str = Form(...)
):
    """
    用户提交代码，自动用多个测试用例评测
    """
    try:
        testcases = json.loads(testcases_json)
        all_passed = True
        failed_cases = []

        for idx, case in enumerate(testcases):
            input_val = case["input"]
            expected = str(case["output"])

            test_code = f"""
{user_code}

if __name__ == "__main__":
    result = solution({repr(input_val)})
    print(result)
"""

            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
                tmp.write(test_code)
                tmp_filename = tmp.name

            completed = subprocess.run(
                ["python", tmp_filename],
                capture_output=True,
                text=True,
                timeout=5
            )

            output = completed.stdout.strip()
            error = completed.stderr.strip()

            if error:
                all_passed = False
                failed_cases.append({
                    "case": idx + 1,
                    "input": input_val,
                    "error": error
                })
            elif output != expected:
                all_passed = False
                failed_cases.append({
                    "case": idx + 1,
                    "input": input_val,
                    "expected": expected,
                    "got": output
                })

        if all_passed:
            return {"status": "success", "result": "全部测试用例通过 ✅"}
        else:
            return {
                "status": "fail",
                "result": "部分测试用例未通过 ❌",
                "details": failed_cases
            }

    except Exception as e:
        return {"status": "fail", "error": str(e)}


@game_router.post("/ai/solve")
def ai_solve_code(
    description: str = Form(...),
    input: str = Form(...),
    output: str = Form(...),
    testcases_json: str = Form(...),
    model: str = Form("mistralai/mistral-7b-instruct:free")
):
    """
    让 AI 尝试编程解题，自动评测其答案
    """
    try:
        # 1. 构造 prompt
        prompt = f"""你现在要解答一道编程题。

题目描述：
{description}

输入说明：
{input}

输出说明：
{output}

请你编写一个函数 solution(...) 来解决这个问题。
不要加多余解释，只返回 Python 代码：
```python
def solution(...):
    ...
```"""

        code_response = ask(prompt, model=model)

        print("\n=== AI 解答代码 ===\n", code_response)

        # 2. 提取代码（从 ```python ... ``` 中）
        match = re.search(r"```python\s*(.+?)```", code_response, re.S)
        code = match.group(1).strip() if match else code_response.strip()

        # 3. 自动评测
        from fastapi.testclient import TestClient
        from backend.main import app

        client = TestClient(app)

        response = client.post(
            "/game/submit",
            data={
                "user_code": code,
                "testcases_json": testcases_json
            }
        )

        return {
            "status": "success",
            "model": model,
            "code": code,
            "eval_result": response.json()
        }

    except Exception as e:
        return {"status": "fail", "error": str(e)}
